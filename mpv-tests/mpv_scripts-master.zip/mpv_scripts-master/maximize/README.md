# maximize

Note: Microsoft Windows only.

[mpv](https://mpv.io/) script for maximizing mpv when exiting full screen or startup on Microsoft Windows using [nircmd](http://www.nirsoft.net/utils/nircmd.html).

Requires nircmdc.exe in PATH

Download nircdm at the bottom of this page: http://www.nirsoft.net/utils/nircmd.html

Download link for the script: https://raw.githubusercontent.com/kevinlekiller/mpv_scripts/master/maximize/maximize.lua

----
#License:

https://github.com/kevinlekiller/mpv_scripts/blob/master/LICENSE
