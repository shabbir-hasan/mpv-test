# dotfiles

These are various configs that I use around the place (mostly on FreeBSD,
will work on Linux and sometimes other OSes as well) that might be useful
for other people.

Currently included:

* mpv (for 0.21 or newer) [good]
* textadept [wip]
* git [good]
