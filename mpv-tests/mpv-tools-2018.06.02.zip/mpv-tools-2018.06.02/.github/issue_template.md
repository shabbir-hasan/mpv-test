<!-- NOTE: Please don't submit any requests for new features. I have almost no -->
<!-- time for the computer anymore, and have absolutely ZERO time to program -->
<!-- any NEW features. However, bug reports are still important, so please do -->
<!-- submit those if you find any bugs. Good pull requests will also be accepted. -->
<!-- // SteveJobzniak -->
