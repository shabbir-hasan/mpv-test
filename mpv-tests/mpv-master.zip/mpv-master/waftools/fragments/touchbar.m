#import <AppKit/AppKit.h>

int main(int argc, char **argv)
{
    [[NSTouchBar alloc] init];
    return 0;
}
